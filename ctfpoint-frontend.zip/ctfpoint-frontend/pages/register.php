<!DOCTYPE HTML>

<html>

    <head>
    <title>Register CTFPoint</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
        <link rel = "stylesheet" href = "../styles/daftar.css">

        <style>
          /*Import font-family poppins.*/
          @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,700&display=swap');
          .navbar {
            font-family: 'Poppins', sans-serif;
          }

          section {
            padding-top: 5rem;
          }
          .navbar-transparent {
            opacity: 90%;
          }

          .card-body{
            /*background-color: #FFEBC1;*/
            background-image: linear-gradient(to right, #D5CEA3, #E5E5CB);
          }
          
          html{
            height: 110%;
          }

          body{
            /*background-image: linear-gradient(to bottom, #8E3200, #D7A86E);*/
            background-color: #3C2A21;
            background-repeat: no-repeat;
            font-family: 'Poppins', sans-serif;
          }

          .dropdown-menu li{
            transition: all 1s ease 0s;
          }

          .dropdown-menu li a:hover {
            background-color: #D7A86E;
            color: black;
          }
        
        </style>
    </head>

    <body>

    <nav class="navbar navbar-expand-lg navbar-dark shadow-sm fixed-top navbar-transparent" style="background-image: linear-gradient(to right, #1A120B, #3C2A21);" > <!-- Notes, coba bkin ke right gradasinya.-->
    <!--<nav class="navbar navbar-expand-lg navbar-dark shadow-sm fixed-top navbar-transparent" style="background-color: #1A120B" >-->
  <div class="container">
    <a class="navbar-brand fw-bolder" href="#home">CTFPoint</a> <!-- fw-bolder, it makes font size bolder-->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto"> <!-- ms-auto class, used to aligned the list in navbar to the right -->
        <li class="nav-item">
          <a class="nav-link me-3 fw-medium" href="#">Event</a> <!-- adding me-3 to add spaces between the navbar link -->
        </li>
        <li class="nav-item">
          <a class="nav-link me-3 fw-medium" aria-current="page" href="#writeups">WriteUps</a>
        </li>
        <li class="nav-item">
          <a class="nav-link me-3 fw-medium" href="#">Articles</a>
        </li>
        <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
      <ul class="navbar-nav">
      <a href = "login.php">
      <button class="btn btn-dark">
            Login
       </button>
       </a>
      </ul>
    </div>
    </div>
  </div>
</nav>
        <div class = "daftar">
        <form onsubmit="login(event)">
            <h2 style = "font-size:40px;font-weight: bold;color:white;" class = "judulutama">Register</h2>
            <div class = "judul">
            <label style = "font-size:20px;font-weight: bold;color:white;">Username</label>
            </div>

            <div class = "register-text">
                <input type="text" name = "username" size = "55">
            </div>

            <div class = "judul">
            <label style = "font-size:20px;font-weight: bold;color:white;">Email</label>
            </div>

            <div class = "register-text">
                <input type="email" name = "email" size = "55">
            </div>

            <div class = "judul">
            <label style = "font-size:20px;font-weight: bold;color:white;">Password</label>
            </div>

            <div class = "register-text">
                <input type="password" name = "password" size = "55">
            </div>
        
            <div class = "judul">
            <label style = "font-size:20px;font-weight: bold;color:white;">Confirm Password</label>
            </div>

            <div class = "register-text">
                <input type="password" name = "confirm" size = "55">
            </div>

            <button type = "submit" class = "btnlogin">Sign Up</button>
        </form>
        <form action="login.php">
            <h6 style = "color: white;padding-top:30px;">Have Account?</h6>
            <input type="submit" class = "btnlogin2" value="Login"/>
        </form>

        <div class = "verif">
        <?php if(isset($user)) { ?>
            <p style="color: black;"><?php echo $user;?></p>
            <a href="#"></a>
        <?php } else if(isset($error)) {
        ?> <p style="font-size:20px;font-weight: bold;color: red;"><?php echo $error; ?></p>
        <?php } ?>
        </div>

        </div>

    </body>



</html>